package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import javax.swing.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class mysqlconnect {
    Connection conn = null;
    public static final String USER = "root";
    public static final String PASS = "root";

    public static Connection ConnectDB() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/pawnshop", USER, PASS);
            System.out.println("Stable");
            return conn;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
    }


    public static ObservableList<stuff> getDataStuff() {

        Connection conn = ConnectDB();
        ObservableList<stuff> list = FXCollections.observableArrayList();
        try {
            PreparedStatement ps = conn.prepareStatement("select * from stuff where status = 1");
            ResultSet rs = ps.executeQuery();
            while (rs.next()){

                list.add(new stuff(Integer.parseInt(rs.getString("stuff_id")), rs.getString("fullname"),
                        rs.getString("stuff_name"), rs.getString("stuff_type"), rs.getDate("local_date"),
                        rs.getDate("final_date"), rs.getInt("money"), rs.getInt("total_sum"), rs.getInt("final_days")));

            }
        } catch (Exception e){
        }

        return list;
    }

    public static ObservableList<del> getDataDel() {

        Connection conn = ConnectDB();
        ObservableList<del> list1 = FXCollections.observableArrayList();
        try {
            PreparedStatement ps = conn.prepareStatement("select * from stuff where status = 0");
            ResultSet rs = ps.executeQuery();
            while (rs.next()){

                list1.add(new del(Integer.parseInt(rs.getString("stuff_id")), rs.getString("fullname"),
                        rs.getString("stuff_name"), rs.getString("stuff_type"), rs.getDate("local_date"),
                        rs.getDate("delete_date"), rs.getInt("money"), rs.getFloat("percent_money")));

            }
        } catch (Exception e){
        }

        return list1;
    }
}
