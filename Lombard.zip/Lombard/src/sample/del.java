package sample;

import java.sql.Date;

public class del {
    int stuff_id;
    String fullname, stuff_name, stuff_type;
    Date local_date, delete_date;
    int money;
    Float percent_money;

    public int getStuff_id() {
        return stuff_id;
    }

    public void setStuff_id(int stuff_id) {
        this.stuff_id = stuff_id;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getStuff_name() {
        return stuff_name;
    }

    public void setStuff_name(String stuff_name) {
        this.stuff_name = stuff_name;
    }

    public String getStuff_type() {
        return stuff_type;
    }

    public void setStuff_type(String stuff_type) {
        this.stuff_type = stuff_type;
    }

    public Date getLocal_date() {
        return local_date;
    }

    public void setLocal_date(Date local_date) {
        this.local_date = local_date;
    }

    public Date getDelete_date() {
        return delete_date;
    }

    public void setDelete_date(Date delete_date) {
        this.delete_date = delete_date;
    }

    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }

    public Float getPercent_money() {
        return percent_money;
    }

    public void setPercent_money(Float percent_money) {
        this.percent_money = percent_money;
    }

    public del(int stuff_id, String fullname, String stuff_name, String stuff_type, Date local_date, Date delete_date, int money, Float percent_money) {
        this.stuff_id = stuff_id;
        this.fullname = fullname;
        this.stuff_name = stuff_name;
        this.stuff_type = stuff_type;
        this.local_date = local_date;
        this.delete_date = delete_date;
        this.money = money;
        this.percent_money = percent_money;
    }
}
