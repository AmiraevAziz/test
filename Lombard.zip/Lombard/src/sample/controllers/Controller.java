package sample.controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Controller {

    @FXML
    private TextField login_field;

    @FXML
    private PasswordField pass_field;

    @FXML
    private Button enter_btn;


    Connection conn = null;
    ResultSet rs = null;
    PreparedStatement pst = null;

    @FXML
    public void loginBtn(javafx.event.ActionEvent event) throws Exception {
        conn = sample.mysqlconnect.ConnectDB();
        String sql1 = "SELECT * FROM user WHERE login = ? and password = ?";
        try {
            pst = conn.prepareStatement(sql1);
            pst.setString(1, login_field.getText());
            pst.setString(2, pass_field.getText());
            rs = pst.executeQuery();
            if (rs.next()) {
                JOptionPane.showMessageDialog(null, "Success");
                enter_btn.getScene().getWindow().hide();
                Parent root = FXMLLoader.load(getClass().getResource("/sample/fxml_files/main_window.fxml"));
                Stage mainStage = new Stage();
                Scene scene = new Scene(root);
                mainStage.setScene(scene);
                mainStage.show();
            } else {
                JOptionPane.showMessageDialog(null, "User not found");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

}
