package sample.controllers;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class test_controller {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Label money1;

    @FXML
    private Label money2;

    @FXML
    private Label result;

    @FXML
    void initialize() {
        money1.setText("5000 som");

    }
}

