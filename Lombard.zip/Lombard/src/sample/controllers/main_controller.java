package sample.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import org.apache.poi.ss.usermodel.Row;
import sample.del;
import sample.mysqlconnect;
import sample.stuff;

import javax.swing.*;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class main_controller  implements Initializable {

    @FXML
    private Button add_btn;

    @FXML
    private Button cont_btn;

    @FXML
    private Button list_btn;

    @FXML
    private Button edit_btn;

    @FXML
    private Button pay_btn;

    @FXML
    private Button setting_btn;

    @FXML
    private Button exit_btn;

    @FXML
    private Pane add_pane;

    @FXML
    private TextField surname_field;

    @FXML
    private TextField id_field;

    @FXML
    private TextField name_field;

    @FXML
    private TextField midname_field;

    @FXML
    private TextField number_field;

    @FXML
    private TextField adress_field;

    @FXML
    private TextField inn_field;

    @FXML
    private TextField stuff_name_field;

    @FXML
    private TextField stuff_type_field;

    @FXML
    private TextField filter_field;

    @FXML
    private TextField money_field;

    @FXML
    private TextField stuff_pr_field;

    @FXML
    private Button done_btn;

    @FXML
    private DatePicker date_field;


    @FXML
    private TextField stuff_name_field1;

    @FXML
    private Pane cont_pane;

    @FXML
    private TableView<stuff> cont_table;

    @FXML
    private TableColumn<stuff, Integer> col_id;

    @FXML
    private TableColumn<stuff, String> col_fname;

    @FXML
    private TableColumn<stuff, String> col_sname;

    @FXML
    private TableColumn<stuff, String> col_type;

    @FXML
    private TableColumn<stuff, Date> col_date;

    @FXML
    private TableColumn<stuff, Date> col_final_date;

    @FXML
    private TableColumn<stuff, Integer> col_sum;

    @FXML
    private TableColumn<stuff, Integer> col_final_sum;

    @FXML
    private TableColumn<stuff, Integer> col_final_days;


    @FXML
    private TextField id_red_field;

    @FXML
    private Button red_btn;

    @FXML
    private Label fullname_label;

    @FXML
    private Label number_label;

    @FXML
    private Label inn_label;

    @FXML
    private Button deleted_btn;

    @FXML
    private Label sname_label;

    @FXML
    private Label type_label;

    @FXML
    private Label sum_label;

    @FXML
    private Label rate_label;

    @FXML
    private Label date_label;

    @FXML
    private Label dir_label;

    @FXML
    private Button back_btn;

    @FXML
    private Button back_btn1;

    @FXML
    private Button back_btn2;

    @FXML
    private Pane main_pane;

    @FXML
    private Pane edit_pane;

    @FXML
    private Pane edit_anc;

    @FXML
    private TextField name_edit;

    @FXML
    private TextField num_edit;

    @FXML
    private TextField address_edit;

    @FXML
    private TextField inn_edit;

    @FXML
    private TextField sname_edit;

    @FXML
    private TextField type_edit;

    @FXML
    private TextField money_edit;

    @FXML
    private TextField proc_edit;

    @FXML
    private DatePicker date_edit;

    @FXML
    private Button edit_button;

    @FXML
    private Button refresh_btn;


    @FXML
    private TextField days_field;


    @FXML
    private Button search_button;

    @FXML
    private TextField search_field;

    @FXML
    private Button back_button;

    @FXML
    private Pane search_pane;

    @FXML
    private Pane list_pane;

    @FXML
    private Label first_date_label;

    @FXML
    private Label s_final_date_label;

    @FXML
    private Label second_date_label;

    @FXML
    private Label start_sum_label;

    @FXML
    private Label percent_label;

    @FXML
    private Label final_sum_label;

    @FXML
    private Label s_stuff_label;

    @FXML
    private Label s_type_stuff_label;

    @FXML
    private Label s_adres_label;

    @FXML
    private Label s_inn_label;

    @FXML
    private Label s_days_label;

    @FXML
    private Label s_number_label;

    @FXML
    private Label username_label;

    @FXML
    private Label s_id_label;

    @FXML
    private Label s_status_label;

    @FXML
    private TextField cont_id_field;

    @FXML
    private TextField cont_days_field;

    @FXML
    private Button done_btn1;

    @FXML
    private Button back_btn_cont;

    @FXML
    private TextField cont_pay_field;

    @FXML
    private Pane end_pane;

    @FXML
    private Button end_back;

    @FXML
    private TextField end_find_field;

    @FXML
    private Button end_find_button;

    @FXML
    private AnchorPane end_anchor;

    @FXML
    private Label end_id;

    @FXML
    private Button end_done_button;

    @FXML
    private Label end_fio;

    @FXML
    private Label end_stuff;

    @FXML
    private Label end_sum;

    @FXML
    private Label end_f_sum;

    @FXML
    private Label end_date;

    @FXML
    private Label end_days;

    @FXML
    private Label end_percent;

    @FXML
    private Pane delete_pane;

    @FXML
    private TableView<del> cont_table1;

    @FXML
    private TableColumn<del, Integer> col_id1;

    @FXML
    private TableColumn<del, String> col_fname1;

    @FXML
    private TableColumn<del, String> col_sname1;

    @FXML
    private TableColumn<del, String> col_type1;

    @FXML
    private TableColumn<del, Date> col_date1;

    @FXML
    private TableColumn<del, Date> col_final_date1;

    @FXML
    private TableColumn<del, Integer> col_sum1;

    @FXML
    private TableColumn<del, Float> col_final_sum1;

    @FXML
    private Button back_btn3;

    @FXML
    private Button refresh_btn1;

    @FXML
    private Pane ban_pane;

    @FXML
    private TextField pass_field;

    @FXML
    private Button pass_done;

    @FXML
    private Button excel_btn1;

    @FXML
    private Button excel_btn;

    ObservableList<stuff> list;
    int index = -1;
    Double sum_proc=0.0;

    Connection conn = null;
    ResultSet rs = null;
    PreparedStatement pst = null;

    public void UpdateTable() {
        col_id.setCellValueFactory(new PropertyValueFactory<stuff, Integer>("stuff_id"));
        col_fname.setCellValueFactory(new PropertyValueFactory<stuff, String>("fullname"));
        col_sname.setCellValueFactory(new PropertyValueFactory<stuff, String>("stuff_name"));
        col_type.setCellValueFactory(new PropertyValueFactory<stuff, String>("stuff_type"));
        col_date.setCellValueFactory(new PropertyValueFactory<stuff, Date>("local_date"));
        col_final_date.setCellValueFactory(new PropertyValueFactory<stuff, Date>("final_date"));
        col_sum.setCellValueFactory(new PropertyValueFactory<stuff, Integer>("money"));
        col_final_sum.setCellValueFactory(new PropertyValueFactory<stuff, Integer>("total_sum"));
        col_final_days.setCellValueFactory(new PropertyValueFactory<stuff, Integer>("final_days"));

        list = mysqlconnect.getDataStuff();
        cont_table.setItems(list);
    }
    ObservableList<del> list1;

    public void UpdateTable2() {
        col_id1.setCellValueFactory(new PropertyValueFactory<del, Integer>("stuff_id"));
        col_fname1.setCellValueFactory(new PropertyValueFactory<del, String>("fullname"));
        col_sname1.setCellValueFactory(new PropertyValueFactory<del, String>("stuff_name"));
        col_type1.setCellValueFactory(new PropertyValueFactory<del, String>("stuff_type"));
        col_date1.setCellValueFactory(new PropertyValueFactory<del, Date>("local_date"));
        col_final_date1.setCellValueFactory(new PropertyValueFactory<del, Date>("delete_date"));
        col_sum1.setCellValueFactory(new PropertyValueFactory<del, Integer>("money"));
        col_final_sum1.setCellValueFactory(new PropertyValueFactory<del, Float>("percent_money"));

        list1 = mysqlconnect.getDataDel();
        cont_table1.setItems(list1);
    }



    @FXML
    void excel(ActionEvent event) throws Exception {
        conn = mysqlconnect.ConnectDB();
        PreparedStatement ps=conn.prepareStatement("Select * from stuff ");
        ResultSet rs = ps.executeQuery();
        ResultSetMetaData rsmd = rs.getMetaData();
        List<String> columns=new ArrayList<String>(){{
            for(int i =1;i<=rsmd.getColumnCount();i++){
                add(rsmd.getColumnLabel(i));
            }
        }};

        try (Workbook book = new XSSFWorkbook()) {
            Sheet sheet = book.createSheet();
            org.apache.poi.ss.usermodel.Row header = sheet.createRow(0);

            for (int i=0;i<columns.size();i++){
                header.createCell(i).setCellValue(columns.get(i));
            }
            int rowIndex=0;
            while(rs.next()){
                Row row=sheet.createRow(++rowIndex);
                for(int i =0;i<columns.size();i++){
                    row.createCell(i).setCellValue(Objects.toString(rs.getObject(columns.get(i)),""));
                }
            }

            try (FileOutputStream fos=new FileOutputStream("C:\\Users\\User\\Desktop\\Pawnshop.xlsx")){
                book.write(fos);
            }catch (IOException e) {
                e.printStackTrace();
            }

        }
        catch (IOException e){
        }
    }
    //ОСТАТОК ДНЕЙ
    public void UpdateDays() throws SQLException {
        conn = mysqlconnect.ConnectDB();
        Statement stmt = conn.createStatement();
        String sql = "SELECT COUNT(*) FROM stuff";
        ResultSet rs = stmt.executeQuery(sql);
        rs.next();
        int count = rs.getInt(1);
        System.out.println(count);


        int x = 13;
        count += x;
        System.out.println(count);
        while (x != count) {
            String days = "SELECT final_date FROM stuff WHERE count_id = ?";
            try {
                pst = conn.prepareStatement(days);
                pst.setInt(1, x);
                rs = pst.executeQuery();
                if (rs.next()) {
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }

            Date fDate = rs.getDate("final_date");


            Date lDate = Date.valueOf(LocalDate.now());

            long milliseconds = fDate.getTime() - lDate.getTime();
            int fDays = (int) (milliseconds / (24 * 60 * 60 * 1000));

            String daysUpdate = "UPDATE stuff SET final_days = ? WHERE count_id = ?";
            try {
                pst = conn.prepareStatement(daysUpdate);
                pst.setInt(1, fDays);
                pst.setInt(2, x);
                pst.execute();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }


            x++;


        }



    }


    @Override
    public void initialize(URL url, ResourceBundle rb) {

        try {
            UpdateDays();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        UpdateTable();
        UpdateTable2();
        edit_anc.setVisible(false);
        end_anchor.setVisible(false);

        search_user();
    }

    @FXML
    void navigation(javafx.event.ActionEvent actionEvent) {
        if (actionEvent.getSource() == add_btn)
            add_pane.toFront();

        if (actionEvent.getSource() == list_btn)
            list_pane.toFront();

        if (actionEvent.getSource() == back_btn)
            main_pane.toFront();

        if (actionEvent.getSource() == back_btn1)
            main_pane.toFront();

        if (actionEvent.getSource() == back_btn2)
            main_pane.toFront();

        if (actionEvent.getSource() == edit_btn)
            edit_pane.toFront();

        if (actionEvent.getSource() == back_btn_cont)
            main_pane.toFront();

        if (actionEvent.getSource() == back_btn3)
            main_pane.toFront();

        if (actionEvent.getSource() == cont_btn)
            cont_pane.toFront();

        if (actionEvent.getSource() == deleted_btn)
            delete_pane.toFront();

        if (actionEvent.getSource() == pay_btn)
            end_pane.toFront();



    }

    //РЕДАКТИРОВАНИЕ СЛЕВА
    public void editUpdate() throws SQLException {
        String id_value = id_red_field.getText();
        conn = mysqlconnect.ConnectDB();
        String sql = "SELECT * FROM stuff WHERE stuff_id = ? AND status = 1";
        try {
            pst = conn.prepareStatement(sql);
            pst.setString(1, id_value);
            rs = pst.executeQuery();
            if (rs.next()) {}
        } catch (SQLException e) {
            e.printStackTrace();

        }


        fullname_label.setText(rs.getString("fullname"));
        number_label.setText(rs.getString("number"));
        dir_label.setText(rs.getString("adress"));
        inn_label.setText(rs.getString("INN"));
        sname_label.setText(rs.getString("stuff_name"));
        type_label.setText(rs.getString("stuff_type"));
        sum_label.setText(rs.getString("money"));
        rate_label.setText(rs.getString("percent"));
        date_label.setText(rs.getString("local_date") + " --- " + rs.getString("final_date"));


    }

    @FXML
    void red_find(ActionEvent actionEvent) throws SQLException {
        editUpdate();
            edit_anc.setVisible(true);

    }

    //РЕДАКТИРОВАНИЕ СПРАВА
    @FXML
    void editButton(ActionEvent actionEvent) throws SQLException {

        String id_value = id_red_field.getText();

        conn = mysqlconnect.ConnectDB();

        String nameEdit = name_edit.getText();
        String numEdit = num_edit.getText();
        String addressEdit = address_edit.getText();
        String innEdit = inn_edit.getText();
        String snameEdit = sname_edit.getText();
        String typeEdit = type_edit.getText();
        String moneyEdit = money_edit.getText();
        String procentEdit = proc_edit.getText();


        if(nameEdit.trim().isEmpty()){}
        else{
            String sql = "UPDATE stuff SET fullname = ? WHERE stuff_id = ?";
            try {
                pst = conn.prepareStatement(sql);
                pst.setString(1, nameEdit);
                pst.setString(2, id_value);
                pst.execute();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }

        if(numEdit.trim().isEmpty()){}
        else{
            String sql = "UPDATE stuff SET number = ? WHERE stuff_id = ?";
            try {
                pst = conn.prepareStatement(sql);
                pst.setString(1, numEdit);
                pst.setString(2, id_value);
                pst.execute();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }

        if(addressEdit.trim().isEmpty()){}
        else{
            String sql = "UPDATE stuff SET adress = ? WHERE stuff_id = ?";
            try {
                pst = conn.prepareStatement(sql);
                pst.setString(1, addressEdit);
                pst.setString(2, id_value);
                pst.execute();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }

        if(innEdit.trim().isEmpty()){}
        else{
            String sql = "UPDATE stuff SET INN = ? WHERE stuff_id = ?";
            try {
                pst = conn.prepareStatement(sql);
                pst.setString(1, innEdit);
                pst.setString(2, id_value);
                pst.execute();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }

        if(snameEdit.trim().isEmpty()){}
        else{
            String sql = "UPDATE stuff SET stuff_name = ? WHERE stuff_id = ?";
            try {
                pst = conn.prepareStatement(sql);
                pst.setString(1, snameEdit);
                pst.setString(2, id_value);
                pst.execute();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }

        if(typeEdit.trim().isEmpty()){}
        else{
            String sql = "UPDATE stuff SET stuff_type = ? WHERE stuff_id = ?";
            try {
                pst = conn.prepareStatement(sql);
                pst.setString(1, typeEdit);
                pst.setString(2, id_value);
                pst.execute();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }

        if(moneyEdit.trim().isEmpty()){}
        else {
            String sql = "UPDATE stuff SET money = ? WHERE stuff_id = ?";
            try {
                pst = conn.prepareStatement(sql);
                pst.setInt(1, Integer.parseInt(money_edit.getText()));
                pst.setString(2, id_value);
                pst.execute();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }

        if(procentEdit.trim().isEmpty()){}
        else {
            String sql = "UPDATE stuff SET percent = ? WHERE stuff_id = ?";
            try {
                pst = conn.prepareStatement(sql);
                pst.setFloat(1, Float.parseFloat(proc_edit.getText()));
                pst.setString(2, id_value);
                pst.execute();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }

        String sql = "SELECT * FROM stuff WHERE stuff_id = ?";
        try {
            pst = conn.prepareStatement(sql);
            pst.setString(1, id_value);
            rs = pst.executeQuery();
            if (rs.next()) {
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        Date test = rs.getDate("final_date");
        java.util.Date test2 = rs.getDate("local_date");
        System.out.println(test);
        System.out.println(test2);


        editUpdate();
        UpdateTable();

        name_edit.setText("");
        num_edit.setText("");
        address_edit.setText("");
        inn_edit.setText("");
        sname_edit.setText("");
        type_edit.setText("");
        money_edit.setText("");
        proc_edit.setText("");
    }

    //ДОБАВЛЕНИЕ
    public void add_btn (ActionEvent event) {
        String user_name = name_field.getText();
        String user_midname = midname_field.getText();
        String user_surname = surname_field.getText();
        String user_fullname = user_name + " " + user_surname + " " + user_midname;

        Date l_date = Date.valueOf(LocalDate.now());

        Float money_x = Float.parseFloat(money_field.getText());
        Float days_x = Float.parseFloat(days_field.getText());
        float percent_x = Float.parseFloat(stuff_pr_field.getText());

        conn = mysqlconnect.ConnectDB();
        String sql = "INSERT INTO stuff (stuff_id, fullname, number, adress, INN, stuff_name, stuff_type, money, local_date, days, final_date, percent,total_sum) " +
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try {
            pst = conn.prepareStatement(sql);
            pst.setInt(1, Integer.parseInt(id_field.getText()));
            pst.setString(2, user_fullname);
            pst.setString(3, number_field.getText());
            pst.setString(4, adress_field.getText());
            pst.setString(5, inn_field.getText());
            pst.setString(6, stuff_name_field.getText());
            pst.setString(7, stuff_type_field.getText());
            pst.setInt(8, Integer.parseInt(money_field.getText()));
            pst.setDate(9, Date.valueOf(LocalDate.now()));
            pst.setInt(10, Integer.parseInt(days_field.getText()));
            pst.setDate(11, Date.valueOf(l_date.toLocalDate().plusDays(Long.parseLong(days_field.getText()))));
            pst.setFloat(12, Float.parseFloat(stuff_pr_field.getText()));
            pst.setFloat( 13,money_x * percent_x / 100 * days_x + money_x);
            pst.execute();
            sum_proc+=money_x * percent_x / 100 * days_x;
            System.out.println(sum_proc);
            JOptionPane.showMessageDialog(null, "Добавлено");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }

        id_field.setText("");
        name_field.setText("");
        midname_field.setText("");
        surname_field.setText("");
        number_field.setText("");
        adress_field.setText("");
        inn_field.setText("");
        stuff_name_field.setText("");
        stuff_pr_field.setText("");
        stuff_type_field.setText("");
        money_field.setText("");
        days_field.setText("");

        UpdateTable();
    }

    @FXML
    void refresh(ActionEvent event) {
        try {
            UpdateDays();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        UpdateTable();
        search_user();
    }

    @FXML
    void refresh1(ActionEvent event) {
        UpdateTable2();
    }


    //ПОИСК
    @FXML
    void search_action(javafx.event.ActionEvent actionEvent) throws SQLException {
        if (actionEvent.getSource() == search_button)
            search_pane.toFront();

        String id_value = search_field.getText();
        conn = mysqlconnect.ConnectDB();
        String sql = "SELECT * FROM stuff WHERE stuff_id = ?";
        try {
            pst = conn.prepareStatement(sql);
            pst.setString(1, id_value);
            rs = pst.executeQuery();
            if (rs.next()) {}
        } catch (SQLException e) {
            e.printStackTrace();
        }

        int status = rs.getInt("status");

        username_label.setText(rs.getString("fullname"));
        s_id_label.setText(String.valueOf(rs.getInt("stuff_id")));
        first_date_label.setText(String.valueOf(rs.getDate("local_date")));
        s_inn_label.setText(rs.getString("INN"));
        s_stuff_label.setText(rs.getString("stuff_name"));
        s_type_stuff_label.setText(rs.getString("stuff_type"));
        start_sum_label.setText(rs.getString("money") + " сом");
        second_date_label.setText(rs.getString("final_date"));
        percent_label.setText(rs.getString("percent" ) + " %");
        final_sum_label.setText(rs.getString("total_sum") + " сом");
        s_adres_label.setText(rs.getString("adress"));
        s_number_label.setText(rs.getString("number"));
        s_days_label.setText(rs.getString("final_days"));
        if (status == 1) {
            s_status_label.setText("Заложен");
        } else s_status_label.setText("Выкуплен");
    }



    @FXML
    void back_action(javafx.event.ActionEvent actionEvent){
        if (actionEvent.getSource() == back_button)
            main_pane.toFront();

        username_label.setText("Пользователь не найден");
        s_id_label.setText(" -");
        first_date_label.setText(" -");
        s_inn_label.setText(" -");
        s_stuff_label.setText(" -");
        s_type_stuff_label.setText(" -");
        start_sum_label.setText(" -");
        second_date_label.setText(" -");
        percent_label.setText(" -");
        final_sum_label.setText(" -");
        s_adres_label.setText(" -");
        s_number_label.setText(" -");
        s_days_label.setText(" -");
        search_field.setText(" ");

    }

    @FXML
    void done_action(ActionEvent event) throws SQLException {
        String user_id_value = cont_id_field.getText();
        int contDays = Integer.valueOf(cont_days_field.getText());
        Float money = Float.valueOf(cont_pay_field.getText());

        conn = mysqlconnect.ConnectDB();
        String sql = "SELECT * FROM stuff WHERE stuff_id = ? AND status = 1";
        try {
            pst = conn.prepareStatement(sql);
            pst.setString(1, user_id_value);
            rs = pst.executeQuery();
            if (rs.next()) {
                JOptionPane.showMessageDialog(null, "Success");
            }else {JOptionPane.showMessageDialog(null, "ID не найден");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        Date finalDate = rs.getDate("final_date");
        Float moneyFirst = rs.getFloat("total_sum");
        Float percentFirst = rs.getFloat("percent");
        Float mainMoney = Float.valueOf(rs.getInt("money"));
        Date dateFirst = Date.valueOf(LocalDate.now());
        Float moneyNow;
        Integer days = rs.getInt("days");

        String update = "UPDATE stuff SET total_sum = ? WHERE stuff_id = ?";

        //исправить сумма меньше 0 перенести в оплаченные

        if (moneyFirst>=0){
            if (money==0){
                moneyNow = (moneyFirst - money) * percentFirst / 100 * contDays;
                sum_proc+=moneyNow;
                System.out.println(sum_proc);
                try {
                    pst = conn.prepareStatement(update);
                    pst.setFloat(1, moneyFirst+moneyNow);
                    pst.setString(2, user_id_value);
                    pst.execute();
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, e);
                }
            }

            //aaaaaaaaaaa
            else if (contDays==0){
                JOptionPane.showMessageDialog(null, "Ошибка");
            }

            else if (contDays == 0 && money == 0){
            }

            else {
            moneyNow = ((moneyFirst - money) * percentFirst / 100 * contDays) + mainMoney;
            sum_proc+=(moneyFirst - money) * percentFirst / 100 * contDays;
            System.out.println(sum_proc);
            try {
                pst = conn.prepareStatement(update);
                pst.setFloat(1, moneyNow);
                pst.setString(2, user_id_value);
                pst.execute();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
        }else{
//            String update3 = "UPDATE stuff SET status = 0 WHERE stuff_id = ?";
//
//            try {
//                pst = conn.prepareStatement(update3);
//                pst.setInt(1, Integer.parseInt(end_find_field.getText()));
//                pst.execute();
//                JOptionPane.showMessageDialog(null, "Готово");
//                end_anchor.setVisible(false);
//
//            } catch (Exception e) {
//                JOptionPane.showMessageDialog(null, e);
//            }
        }


        String update2 = "UPDATE stuff SET final_date = ? WHERE stuff_id = ?";

        try {
            pst = conn.prepareStatement(update2);
            pst.setDate(1, Date.valueOf(finalDate.toLocalDate().plusDays(Long.parseLong(cont_days_field.getText()))));
            pst.setString(2, user_id_value);
            pst.execute();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }

        String update3 = "UPDATE stuff SET days = ? WHERE stuff_id = ?";

        try {
            pst = conn.prepareStatement(update3);
            pst.setInt(1, contDays+days);
            pst.setString(2, user_id_value);
            pst.execute();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }

        String update4 = "UPDATE stuff SET local_date = ? WHERE stuff_id = ?";

        try {
            pst = conn.prepareStatement(update4);
            pst.setDate(1, dateFirst);
            pst.setString(2, user_id_value);
            pst.execute();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }

        cont_id_field.setText("");
        cont_days_field.setText("");
        cont_pay_field.setText("");
        UpdateDays();
    }


    //ВЫКУПЛЕННЫЕ
    @FXML
    void end_action(ActionEvent event) throws SQLException {
        String update3 = "UPDATE stuff SET status = 0 WHERE stuff_id = ?";

        try {
            pst = conn.prepareStatement(update3);
            pst.setInt(1, Integer.parseInt(end_find_field.getText()));
            pst.execute();
            JOptionPane.showMessageDialog(null, "Готово");
            end_anchor.setVisible(false);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }

        String sql = "SELECT * FROM stuff WHERE stuff_id = ?";
        try {
            pst = conn.prepareStatement(sql);
            pst.setString(1, end_find_field.getText());
            rs = pst.executeQuery();
            if (rs.next()) {
            }else {JOptionPane.showMessageDialog(null, "ID не найден");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        Date fDate = rs.getDate("local_date");

        Date lDate = Date.valueOf(LocalDate.now());

        long milliseconds = lDate.getTime() - fDate.getTime();
        int fDays = (int) (milliseconds / (24 * 60 * 60 * 1000));


        String update = "UPDATE stuff SET delete_date = ? WHERE stuff_id = ?";
        try {
            pst = conn.prepareStatement(update);
            pst.setDate(1, Date.valueOf(LocalDate.now()));
            pst.setInt(2, Integer.parseInt(end_find_field.getText()));
            pst.execute();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }

        Float money = rs.getFloat("money");

        Float fSum = rs.getFloat("total_sum");
        String update2 = "UPDATE stuff SET percent_money = ? WHERE stuff_id = ?";
        try {
            pst = conn.prepareStatement(update2);
            pst.setDouble(1, fSum-money);
            pst.setInt(2, Integer.parseInt(end_find_field.getText()));
            pst.execute();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }

        end_id.setText("");
        end_fio.setText("");
        end_stuff.setText("");
        end_sum.setText("");
        end_f_sum.setText("");
        end_date.setText("");
        end_days.setText("");
        end_percent.setText("");
        end_find_field.setText("");
        UpdateTable2();
    }


    @FXML
    void end_back(javafx.event.ActionEvent actionEvent) {
        if (actionEvent.getSource() == end_back)
            main_pane.toFront();
    }

    ObservableList<stuff> dataList;

    @FXML
    void search_user() {
        col_fname.setCellValueFactory(new PropertyValueFactory<stuff, String>("fullname"));

        dataList = mysqlconnect.getDataStuff();
        cont_table.setItems(dataList);
        FilteredList<stuff> filteredData = new FilteredList<>(dataList, b -> true);
        filter_field.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(person -> {
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }
                String lowerCaseFilter = newValue.toLowerCase();

                if (person.getFullname().toLowerCase().contains(lowerCaseFilter)) {
                    return true;
                }else {
                    return false;
                }
            });
        });
        SortedList<stuff> sortedData = new SortedList<>(filteredData);
        sortedData.comparatorProperty().bind(cont_table.comparatorProperty());
        cont_table.setItems(sortedData);
    }



    @FXML
    void end_find_action(ActionEvent event) throws SQLException {
        String check = end_find_field.getText();
        if (check.trim().isEmpty()) {}
        else {
            end_anchor.setVisible(true);

            String sql = "SELECT * FROM stuff WHERE stuff_id = ? AND status = 1";
            try {
                pst = conn.prepareStatement(sql);
                pst.setString(1, end_find_field.getText());
                rs = pst.executeQuery();
                if (rs.next()) {
                }else {JOptionPane.showMessageDialog(null, "ID не найден");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }




            Date fDate = rs.getDate("local_date");

            Date lDate = Date.valueOf(LocalDate.now());

            long milliseconds = lDate.getTime() - fDate.getTime();
            int fDays = (int) (milliseconds / (24 * 60 * 60 * 1000));
            Float money = rs.getFloat("money");

            Float fSum = rs.getFloat("total_sum");

            System.out.println(fSum);

            end_id.setText(end_find_field.getText());
            end_fio.setText(rs.getString("fullname"));
            end_stuff.setText(rs.getString("stuff_name") + " - " + rs.getString("stuff_type"));
            end_sum.setText(String.valueOf(rs.getInt("money")));
            end_f_sum.setText(String.valueOf(fSum-money));
            end_date.setText(String.valueOf(rs.getDate("local_date")));
            end_days.setText(String.valueOf(fDays));
            end_percent.setText(String.valueOf(rs.getString("percent")));



        }

    }

    @FXML
    void pass_done_action(ActionEvent event) throws SQLException {
        String sql = "SELECT * FROM user WHERE id_user = 1";
        try {
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if (rs.next()) {
            }else {JOptionPane.showMessageDialog(null, "ID не найден");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        Date date = rs.getDate("date");
        String date_str = String.valueOf(date);

        int inPass = Integer.parseInt(date_str.replaceAll("-", ""));

        String stPass = String.valueOf(inPass);

        int pass_sqr = Integer.parseInt(stPass.substring(4));

        int pass = pass_sqr * pass_sqr;






    }


}

